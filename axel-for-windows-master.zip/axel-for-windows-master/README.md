# axel-for-windows (v.2.4)

## NOTE: If you don't know how to use it, just run Axel.cmd instead!

Usage: axel [options] url1 [url2] [url...]

-max-speed=x -s x Specify maximum speed (bytes per second)

–num-connections=x -n x Specify maximum number of connections

–output=f -o f Specify local output file

–search[=x] -S [x] Search for mirrors and download from x servers

–header=x -H x Add header string

–user-agent=x -U x Set user agent

–no-proxy -N Just don’t use any proxy server

–quiet -q Leave stdout alone

–verbose -v More status information

–alternate -a Alternate progress indicator

–help -h This information

–version -V Version information
