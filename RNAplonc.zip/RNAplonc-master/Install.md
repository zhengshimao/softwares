# INSTALL

# txCdsPRedict:

For installation of txCdsPredict follow the existing README file in the txCdsPredict file in the download section. The README file is located in the: Kent/README

After the uncompressed zip file, the path of the txCdsPredict will be:: kent/src/hg/txCds/txCdsPredict. The executable file will be txCdsPredict.c

# CD-HIT-EST:

To install the CD-HIT-EST follow the README in the CD-HIT-EST file in the download section. README file is located in the uncompressed zip: cdhit-master/README

After the uncompressed zip file, the path of the CD-HIT-EST will be: cdhit-master/cd-hit-est

Other files do not require installation.

