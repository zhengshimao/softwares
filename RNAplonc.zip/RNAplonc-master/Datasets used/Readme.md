#RNAplonc - training : divided in lncRNA and transcripts (https://github.com/TatianneNegri/RNAplonc/blob/master/Datasets%20used/treino/lncRNA_dataset.fasta) and transcripts. <br>

Training set transcripts is.<br>
transcripts  : https://github.com/TatianneNegri/RNAplonc/blob/master/Datasets%20used/treino/transcritos_dataset.fasta<br>


#RNAplonc - test : dataset of 8 plant species divided in lncRNA and trasncripts.<br>
lncRNA: https://github.com/TatianneNegri/RNAplonc/tree/master/Datasets%20used/test/lncRNA <br>
transcripts: https://github.com/TatianneNegri/RNAplonc/tree/master/Datasets%20used/test/transcritos<br>

#Four case-of-study
Gossypium barbadense: https://github.com/TatianneNegri/RNAplonc/tree/master/Datasets%20used/Brachypodium_distachyon<br>
Retracted from article: M. Wang, D. Yuan, L. Tu, W. Gao, Y. He, H. Hu, P. Wang, N. Liu, K. Lindsey, and X. Zhang. Long noncoding RNAs and their proposed functions in fibre development of cotton (Gossypium spp.). The New phytologist, 207(4):1181–1197, Sep 2015.<br>


Populus tomentosa:https://github.com/TatianneNegri/RNAplonc/blob/master/Datasets%20used/Populus/seq.fasta<br>
Retracted from article: M. Chen, C. Wang, H. Bao, H. Chen, and Y. Wang. Genome-wide identification and characterization of novel lncRNAs in Populus under nitrogen deficiency. Molecular genetics and genomics : MGG, 291(4):1663–1680, Aug 2016.<br>

Populus tomentosa: https://github.com/TatianneNegri/RNAplonc/blob/master/Datasets%20used/Populus/425_2014_2168.fastaa <br>
Retracted from article: J. Chen, M. Quan, and D. Zhang. Genome-wide identification of novel long non-coding RNAs in Populus tomentosa tension wood, opposite wood and normal wood xylem by RNA-seq. Planta, 241(1):125–143, Jan 2015.<br>

Brachypodium distachyon: https://github.com/TatianneNegri/RNAplonc/tree/master/Datasets%20used/Gossypium<br>
Retracted from article: C. Quattro, M. Enrico Pe, and E. Bertolini.(2017). Long noncoding RNAsin the model species Brachypodium distachyon..Sci Rep, 11252
